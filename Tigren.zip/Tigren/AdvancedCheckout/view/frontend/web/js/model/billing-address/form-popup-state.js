define([
	    'ko'
	], function (ko) {
	    'use strict';

	    return {
		isVisible: ko.observable(false)
	    };
	});